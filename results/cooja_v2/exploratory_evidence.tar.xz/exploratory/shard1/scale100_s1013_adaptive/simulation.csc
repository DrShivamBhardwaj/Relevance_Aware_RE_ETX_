<?xml version='1.0' encoding='UTF-8'?>
<simconf version="2022112801">
  <simulation>
    <title>Payload allocation adaptive seed 1013</title>
    <randomseed>1013</randomseed>
    <motedelay_us>0</motedelay_us>
    <radiomedium>org.contikios.cooja.radiomediums.UDGM<transmitting_range>34</transmitting_range>
      <interference_range>68</interference_range>
      <success_ratio_tx>1</success_ratio_tx>
      <success_ratio_rx>0.98</success_ratio_rx>
    </radiomedium>
    <motetype>org.contikios.cooja.contikimote.ContikiMoteType<identifier>allocation</identifier>
      <description>Progressive source with live context</description>
      <source>/workspace/scratch/4b6f51f568a1/cooja_robustness_v2/shard1/scale100_s1013_adaptive/allocation.c</source>
      <commands>make -j2 allocation.cooja TARGET=cooja CONTIKI=/workspace/scratch/4b6f51f568a1/contiki-ng STUDY_ROUTING=1</commands>
      <moteinterface>org.contikios.cooja.interfaces.Position</moteinterface>
      <moteinterface>org.contikios.cooja.interfaces.Battery</moteinterface>
      <moteinterface>org.contikios.cooja.contikimote.interfaces.ContikiVib</moteinterface>
      <moteinterface>org.contikios.cooja.contikimote.interfaces.ContikiMoteID</moteinterface>
      <moteinterface>org.contikios.cooja.contikimote.interfaces.ContikiRS232</moteinterface>
      <moteinterface>org.contikios.cooja.contikimote.interfaces.ContikiBeeper</moteinterface>
      <moteinterface>org.contikios.cooja.interfaces.RimeAddress</moteinterface>
      <moteinterface>org.contikios.cooja.interfaces.IPAddress</moteinterface>
      <moteinterface>org.contikios.cooja.contikimote.interfaces.ContikiRadio</moteinterface>
      <moteinterface>org.contikios.cooja.contikimote.interfaces.ContikiButton</moteinterface>
      <moteinterface>org.contikios.cooja.contikimote.interfaces.ContikiPIR</moteinterface>
      <moteinterface>org.contikios.cooja.contikimote.interfaces.ContikiClock</moteinterface>
      <moteinterface>org.contikios.cooja.contikimote.interfaces.ContikiLED</moteinterface>
      <moteinterface>org.contikios.cooja.contikimote.interfaces.ContikiCFS</moteinterface>
      <moteinterface>org.contikios.cooja.contikimote.interfaces.ContikiEEPROM</moteinterface>
      <moteinterface>org.contikios.cooja.interfaces.Mote2MoteRelations</moteinterface>
      <moteinterface>org.contikios.cooja.interfaces.MoteAttributes</moteinterface>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="90" y="210" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>1</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="1" y="0" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>2</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="19" y="2" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>3</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="42" y="-2" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>4</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="61" y="-2" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>5</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="81" y="-1" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>6</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="100" y="-2" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>7</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="120" y="-2" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>8</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="142" y="1" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>9</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="160" y="-2" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>10</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="179" y="0" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>11</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="0" y="19" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>12</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="21" y="20" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>13</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="40" y="19" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>14</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="58" y="19" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>15</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="81" y="18" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>16</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="101" y="18" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>17</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="121" y="21" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>18</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="142" y="19" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>19</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="158" y="20" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>20</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="180" y="20" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>21</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="2" y="39" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>22</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="18" y="40" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>23</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="42" y="42" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>24</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="60" y="41" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>25</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="81" y="42" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>26</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="98" y="40" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>27</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="120" y="40" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>28</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="141" y="41" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>29</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="161" y="41" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>30</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="178" y="40" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>31</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="0" y="59" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>32</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="20" y="60" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>33</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="39" y="60" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>34</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="58" y="59" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>35</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="82" y="61" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>36</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="99" y="61" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>37</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="122" y="58" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>38</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="139" y="62" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>39</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="162" y="60" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>40</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="180" y="58" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>41</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="0" y="79" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>42</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="19" y="80" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>43</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="40" y="78" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>44</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="62" y="82" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>45</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="80" y="78" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>46</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="99" y="79" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>47</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="121" y="81" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>48</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="139" y="80" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>49</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="162" y="81" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>50</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="182" y="78" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>51</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="-2" y="100" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>52</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="22" y="99" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>53</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="38" y="100" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>54</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="61" y="100" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>55</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="82" y="99" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>56</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="98" y="98" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>57</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="119" y="101" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>58</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="141" y="98" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>59</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="159" y="99" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>60</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="178" y="98" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>61</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="1" y="120" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>62</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="18" y="122" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>63</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="40" y="118" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>64</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="62" y="121" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>65</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="81" y="121" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>66</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="99" y="120" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>67</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="120" y="120" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>68</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="140" y="119" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>69</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="158" y="118" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>70</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="178" y="120" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>71</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="-1" y="141" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>72</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="21" y="142" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>73</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="42" y="142" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>74</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="62" y="138" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>75</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="81" y="140" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>76</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="98" y="141" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>77</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="119" y="138" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>78</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="141" y="139" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>79</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="158" y="141" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>80</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="180" y="140" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>81</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="2" y="159" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>82</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="18" y="160" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>83</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="41" y="159" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>84</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="61" y="159" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>85</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="79" y="160" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>86</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="98" y="162" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>87</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="119" y="161" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>88</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="140" y="162" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>89</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="159" y="162" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>90</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="182" y="160" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>91</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="2" y="178" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>92</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="22" y="182" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>93</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="40" y="181" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>94</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="60" y="180" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>95</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="81" y="180" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>96</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="101" y="178" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>97</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="122" y="181" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>98</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="138" y="180" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>99</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="158" y="181" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>100</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="181" y="180" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>101</id>
        </interface_config>
      </mote>
    </motetype>
  </simulation>
  <plugin>org.contikios.cooja.plugins.ScriptRunner<plugin_config>
      <script>TIMEOUT(690000);
var done = 0;
while(true) {
  log.log(time + ":" + id + ":" + msg + "\n");
  if(msg.indexOf("DONE,") == 0) { done++; if(done == 101) GENERATE_MSG(10000, "STUDY_DRAIN"); }
  if(msg.equals("STUDY_DRAIN")) log.testOK();
  YIELD();
}</script>
      <active>true</active>
    </plugin_config>
  </plugin>
</simconf>