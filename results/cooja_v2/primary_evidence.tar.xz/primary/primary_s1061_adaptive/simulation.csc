<?xml version='1.0' encoding='UTF-8'?>
<simconf version="2022112801">
  <simulation>
    <title>Payload allocation adaptive seed 1061</title>
    <randomseed>1061</randomseed>
    <motedelay_us>0</motedelay_us>
    <radiomedium>org.contikios.cooja.radiomediums.UDGM<transmitting_range>34</transmitting_range>
      <interference_range>68</interference_range>
      <success_ratio_tx>1</success_ratio_tx>
      <success_ratio_rx>0.98</success_ratio_rx>
    </radiomedium>
    <motetype>org.contikios.cooja.contikimote.ContikiMoteType<identifier>allocation</identifier>
      <description>Progressive source with live context</description>
      <source>/home/runner/work/Relevance_Aware_RE_ETX_/Relevance_Aware_RE_ETX_/cooja-output/study/primary_s1061_adaptive/allocation.c</source>
      <commands>make -j2 allocation.cooja TARGET=cooja CONTIKI=/home/runner/work/Relevance_Aware_RE_ETX_/Relevance_Aware_RE_ETX_/contiki STUDY_ROUTING=1</commands>
      <moteinterface>org.contikios.cooja.interfaces.Position</moteinterface>
      <moteinterface>org.contikios.cooja.interfaces.Battery</moteinterface>
      <moteinterface>org.contikios.cooja.contikimote.interfaces.ContikiVib</moteinterface>
      <moteinterface>org.contikios.cooja.contikimote.interfaces.ContikiMoteID</moteinterface>
      <moteinterface>org.contikios.cooja.contikimote.interfaces.ContikiRS232</moteinterface>
      <moteinterface>org.contikios.cooja.contikimote.interfaces.ContikiBeeper</moteinterface>
      <moteinterface>org.contikios.cooja.interfaces.RimeAddress</moteinterface>
      <moteinterface>org.contikios.cooja.interfaces.IPAddress</moteinterface>
      <moteinterface>org.contikios.cooja.contikimote.interfaces.ContikiRadio</moteinterface>
      <moteinterface>org.contikios.cooja.contikimote.interfaces.ContikiButton</moteinterface>
      <moteinterface>org.contikios.cooja.contikimote.interfaces.ContikiPIR</moteinterface>
      <moteinterface>org.contikios.cooja.contikimote.interfaces.ContikiClock</moteinterface>
      <moteinterface>org.contikios.cooja.contikimote.interfaces.ContikiLED</moteinterface>
      <moteinterface>org.contikios.cooja.contikimote.interfaces.ContikiCFS</moteinterface>
      <moteinterface>org.contikios.cooja.contikimote.interfaces.ContikiEEPROM</moteinterface>
      <moteinterface>org.contikios.cooja.interfaces.Mote2MoteRelations</moteinterface>
      <moteinterface>org.contikios.cooja.interfaces.MoteAttributes</moteinterface>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="40" y="110" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>1</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="2" y="0" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>2</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="20" y="-1" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>3</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="41" y="0" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>4</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="62" y="-2" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>5</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="78" y="1" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>6</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="-1" y="20" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>7</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="20" y="21" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>8</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="41" y="20" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>9</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="62" y="20" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>10</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="80" y="21" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>11</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="2" y="40" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>12</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="18" y="38" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>13</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="41" y="41" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>14</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="61" y="38" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>15</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="80" y="42" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>16</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="-1" y="59" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>17</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="18" y="61" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>18</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="40" y="58" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>19</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="61" y="58" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>20</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="80" y="60" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>21</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="2" y="81" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>22</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="19" y="80" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>23</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="42" y="78" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>24</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="62" y="80" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>25</id>
        </interface_config>
      </mote>
      <mote>
        <interface_config>org.contikios.cooja.interfaces.Position<pos x="79" y="81" />
        </interface_config>
        <interface_config>org.contikios.cooja.contikimote.interfaces.ContikiMoteID<id>26</id>
        </interface_config>
      </mote>
    </motetype>
  </simulation>
  <plugin>org.contikios.cooja.plugins.ScriptRunner<plugin_config>
      <script>TIMEOUT(690000);
var done = 0;
while(true) {
  log.log(time + ":" + id + ":" + msg + "\n");
  if(msg.indexOf("DONE,") == 0) { done++; if(done == 26) GENERATE_MSG(10000, "STUDY_DRAIN"); }
  if(msg.equals("STUDY_DRAIN")) log.testOK();
  YIELD();
}</script>
      <active>true</active>
    </plugin_config>
  </plugin>
</simconf>